
<?php include "includes/header.php" ?>
		<!--navbar end-->
	<!-------register area start--------->
	<section id="register">
		<div class="container mian-regis" style="margin-top: 100px;">
			<div class="row">
				<div class="col-md-6 mb-3">
					<section id="login">
						<div class="card p-3 bg-light">
							<div class="card-body hero-left1">
								<h5 class="card-title ">Register Account</h5>
								<p class="card-text text-justify">You can chat with anchor trade, get notifications of
									order progress and keep track of the orders you have previously made.!</p>
								<a href="#myModal" data-toggle="modal">REGISTRATION</a>
							</div>
						</div>
						<!-- Modal HTML -->
						<div id="myModal" class="modal fade">
                    <div class="modal-dialog modal-login">
                        <div class="modal-content">
                            <form action="/examples/actions/confirmation.php" method="post">
                                <div class="modal-header">
                                    <h4 class="modal-title">Registration</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group d-sm-inline-block d-block pr-2">
                                        <label>Firstname</label>
                                        <input type="text" name="f-name" class="form-control" required="required">
                                    </div>
                                    <div class="form-group d-sm-inline-block d-block ">
                                        <label>Lastname</label>
                                        <input type="text" name="l-name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input type="text" name="u-name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Country</label>
                                        <input type="text" name="country" class="form-control" required="required">
                                    </div>
                                    <div class="form-group d-sm-inline-block d-block  pr-2">
                                        <label>City</label>
                                        <input type="text" name="city" class="form-control" required="required">
                                    </div>
                                    <div class="form-group d-sm-inline-block d-block">
                                        <label>Zip</label>
                                        <input type="number" name="zip" class="form-control" required="required">
                                    </div>
                                    <div class="form-group">
                                        <label>Referral</label>
                                        <input type="text" name="referral" class="form-control" required="required">
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" required="required">
                                    </div>
                                    <div class="form-group">
                                    <label>Password</label>
                                        <input type="password" name="password" class="form-control" required="required">
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <label class="form-check-label"><input type="checkbox"> Remember me</label>
                                    <input type="submit" class="btn btn-primary" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
						<!--------------------------------------->
					</section>
				</div>
				<!--col-md-6-->
				<div class="col-md-6">
					<form method="POST">
						<section id="login">
							<div class="card p-3 bg-light mb-5">
								<div class="card-body">
									<h5 class="card-title ">I am a returning customer</h5>
									<div class="form-group">
										<label for="email">Email address:</label>
										<input type="email" name="email" class="form-control" placeholder="Enter email"
											id="email" required="">
									</div>

									<div class="form-group">
										<label for="pwd">Password:</label>
										<input type="password" name="password" class="form-control"
											placeholder="Enter password" id="pwd" required="">
										<p>Forgetten Password</p>
									</div>

									<a href="#"><button type="submit" name="submit"
											class="btn btn-primary">Login</button></a>
								</div>
							</div>
						</section>

					</form>
					<!--from-->
				</div>
			</div>
		</div>
		<!--------------------------------------->

	</section>
	<?php include "includes/footer.php" ?>