<?php include "includes/header.php" ?>
<!--Product start-->
<div class="container">
<div class="row mt-5 mb-5">
<div class="col-md-4 mt-5 mb-5">
<img src="assets/img/product 1.png" alt="" class="img-fluid">
<h4 class="pt-4">AINSTEIN</h4>
<p class="pt-2">For international traders, with control in the user’s hands, supporting settings adjustment to manage strategy and risk with manual trades. The trade opportunity alerts do not require user approval.</p>
<button style="background-color:transparent; border:2px solid black; padding:5px 15px; font-size:18px; line-height:30px;"><a href="" class="text-decoration-none text-dark font-weight-bold">Learn More</a></button>
</div>
</div>
</div>
<!--Product end-->
<?php include "includes/footer.php" ?>
