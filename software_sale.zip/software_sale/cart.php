
    <?php include "includes/header.php" ?>
	<!--navbar end-->
	<!--Cart Section-->
	<div class="container-fluid mt-5 mb-5">
		<div class="row">
			<div class="col-md-12 ml-3">
				<h1 class="cart_heading mt-5">Your Shopping Cart</h1>
			</div>
			<div class="col col-md-12 ml-3  ">
				<div class="cart_section">
					<i class="fas fa-shopping-cart " style="color: #1e85be;"></i>
					<p class="d-inline cart_text ml-2">Your cart is currently empty.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col col-md-12 ml-3 mt-3  mb-5">
				<a href="#" class="cart_btn">Return to shop</a>
			</div>
		</div>
	</div>
	<!--Cart Section end-->
	<?php include "includes/footer.php" ?>