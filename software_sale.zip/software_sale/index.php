<?php include "includes/header.php" ?>
    <!--Hero section start-->
    <section class="img_banner1" style="background-image: url(assets/img/banner.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-10 col-text-center hero-main">
                    <div class="hero-left">
                        <h2 class="h2_banner1 text-white text-left align-items-center">Design Your
                            Future.<br>Build
                            Your Legacy.</h2>
                        <p class="p_banner1 text-left text-white">Anchor trade is a digital innovation company that
                            equips and
                            empowers people
                            all over the world with the education and tools they need to maximize their QOL (Quality of
                            Life).</p>
                        <!-- Button HTML (to Trigger Modal) -->
                        <a href="#myModal" class="trigger-btn" data-toggle="modal">REGISTRATION</a>
                    </div>
                </div>
                <!-- Modal HTML -->
                <div id="myModal" class="modal fade">
                    <div class="modal-dialog modal-login">
                        <div class="modal-content">
                            <form action="/examples/actions/confirmation.php" method="post">
                                <div class="modal-header">
                                    <h4 class="modal-title">Registration</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group d-sm-inline-block d-block pr-2">
                                        <label>Firstname</label>
                                        <input type="text" name="f-name" class="form-control" required="required">
                                    </div>
                                    <div class="form-group d-sm-inline-block d-block ">
                                        <label>Lastname</label>
                                        <input type="text" name="l-name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input type="text" name="u-name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Country</label>
                                        <input type="text" name="country" class="form-control" required="required">
                                    </div>
                                    <div class="form-group d-sm-inline-block d-block  pr-2">
                                        <label>City</label>
                                        <input type="text" name="city" class="form-control" required="required">
                                    </div>
                                    <div class="form-group d-sm-inline-block d-block">
                                        <label>Zip</label>
                                        <input type="number" name="zip" class="form-control" required="required">
                                    </div>
                                    <div class="form-group">
                                        <label>Referral</label>
                                        <input type="text" name="referral" class="form-control" required="required">
                                    </div>
                                    <div class="form-group">
                            <label for="image">Uplode Profile</label>
                            <div class="custom-file">
                            <input type="file" class="custom-file-input" id="image">
                            <label for="image" class="custom-file-label">Choose file</label>
                            </div>
                            <small class="text-muted">Max size 3MB</small>
                        </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" required="required">
                                    </div>
                                    <div class="form-group">
                                    <label>Password</label>
                                        <input type="password" name="password" class="form-control" required="required">
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <label class="form-check-label"><input type="checkbox"> Remember me</label>
                                    <input type="submit" class="btn btn-primary" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--------------------------------------->
                <div class="col-lg-6 col-md-6 text-center d-none d-md-block text-white">
                    <i aria-hidden="true" class="far fa-play-circle"></i>
                </div>
            </div>
        </div>
    </section>
    <!--Hero Section End-->

    <!--Section2 start-->
    <section class="section2">
        <div class="container">
            <div class="row jus-center">
                <div class="col-8 col-lg-6 col-md-5 heihg">
                    <img src="assets/img/section-2.png" class="im mt-3" alt="">
                </div>
                <div class="col-lg-6 col-md-7 mb-5">
                    <h2 class="section_2_h2 pt-3 ml-5">Maximize Your Quality of Life</h2>
                    <h3 class="section_2_h3 ml-5">POWERFUL TOOLS DESIGNED FOR YOU</h3>
                    <p class="p_section_2 ml-5">We offer our clients analytical tools to help them build a true legacy. We
                        use our core values to provide
                        our affiliates with an opportunity that is run the right way, creating stability and security.
                        And last, but not least,
                        to care for our employees, and their families as we create our
                        individual and joint legacies. We are about creating legacies the right way.</p>
                    <a href="#" class="section2_btn_link ml-5"><button class="btn_section2">GET TO KNOW US</button></a>
                </div>
            </div>
        </div>
    </section>
    <!--Section2 End-->
    <!--Section3 Start-->
    <div class="section3">
        <div class="section3_banner" style="background-image: url(assets/img/img_banner_3.jpg);">
            <div class="container">
                <div class="row jus-center">
                    <div class="col-8 col-lg-6 col-md-5 text-center mt-3">
                        <img src="assets/img/section3_product_img.png"
                            class="img-fluid section3_img"></img>
                    </div>
                    <div class="col-lg-6 col-md-7">
                        <h1 class="section3_margin_h1 ml-5 mt-3">Advanced A.I. Software</h1>
                        <h3 class="ml-5 h">MASTER FOREX TRADING</h3>
                        <p class="ml-5 p">Advanced A.I. Software allows you to potentially identify and take
                            advantage of trends while being in full control of your trades. We have bundled our trading
                            software
                            with everything you need including Auvoria Connect VPS Solution, AP Academy, and a Mobile
                            App. </p>
                        <a href="#" class="section2_btn_link ml-5"><button class="btn_section2">GET TO KNOW
                                US</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Section3 End-->
    <!--Section5 Start-->
    <div class="section5">
        <div class="section5_banner" style="background-image: url(assets/img/4858794.jpg);">
            <div class="container">
                <div class="row jus-center">
                    <div class="col-8 col-lg-6 col-md-5">
                        <img src="assets/img/robot-remove.png" class="img-fluid left-img" alt="">
                    </div>
                    <div class="col-lg-6 col-md-7">
                        <h2 class="section5_h1 mt-3">Ready to Learn What Auvoria <br>PrimeTM Can Do For You?</h2>
                        <p class="section5_p">Our packages have everything you need to get started quickly and with the
                            support
                            necessary for your success. Our products and packages have been designed to empower you with
                            the the most exciting and innovative technologies
                            so that you can work in the largest financial market in the world. We are Auvoria PrimeTM!
                        </p>
                        <a href="#" class="section2_btn_link"><button class="btn_section2">EXPLORE OUR
                                PRODUCT</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "includes/footer.php" ?>