<?php include "includes/header.php" ?>
<!--Product start-->
<div class="container">
<div class="row">
<div class="col-md-5">

</div>
<div class="col-md-7">
<img src="assets/img/blue_Ellipse.png" alt="">
<img src="assets/img/product 1.png" class="position-absolute abs" alt="">
<div class="inner">
</div>
</div>

</div>
</div>
</div>
<!--Product end-->
<?php include "includes/footer.php" ?>
