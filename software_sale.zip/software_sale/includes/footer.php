    <!--Section5 End-->
    <footer>
        <div class="container-fluid jumbotron mb-0">
            <div class="row ">
                <div class="col-lg-3 col-md-6 footer-p">
                    <img src="assets/img/logo.png" class="img-fluid">
                    <p>Anchor trade, LTD is the gateway to innovative technology.
                        We believe we can empower individuals through education, skillful training, and by providing
                        tools
                        to teach people how they can participate in financial markets in a safe and compliant manner.
                    </p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer_product">
                        <h5>PRODUCTS</h5>
                        <p>Ainstrein</p>
                        <p>AIRIS</p>
                        <P>Alexander</P>
                        <h5>MEMBER RESOURCES</h5>
                        <p>My Account</p>
                        <p>Login</p>
                        <p>Contact Us</p>
                        <p>Help Desk</p>
                        <p>Ap Academy</p>
                        <p>Share Auvoria</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer_who footer_product">
                        <h5>WHO WEARE</h5>
                        <p>About Us</p>
                        <p>Leadership & Team</p>
                        <p>Humanitarian Project</p>
                        <h5>WHERE WE ARE</h5>
                        <p>Promotions & Events</p>
                        <h5>CONNECT WITH US</h5>
                        <p>News & Updates</p>
                        <p>Research & Development</p>
                        <p>Investors & Partners</p>
                        <p>Employment Opportunitiest</p>
                        <p>Affiliate Program</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer_united footer_product">
                        <h5>UNITED STATES</h5>
                        <p>Auvoria Prime,LLC</p>
                        <p>30 North Gould St.</p>
                        <p>Suite R</p>
                        <p>Sheridan, WY 82801</p>
                        <p>United States</p>
                        <p>‪+1 307 209 4584</p>
                        <h5>EUROPE</h5>
                        <p>Auvoria Prime, LTD</p>
                        <p>115 Mare Street</p>
                        <p>‪London, Greater London</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="assets/js/script.js"></script>

</html>